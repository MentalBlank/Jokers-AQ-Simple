<?php
/**
 * Created by PhpStorm.
 * User: Joker
 * Date: 3/5/2015
 * Time: 8:54 AM
 */

header("Location: http://localhost/game.asp");
die();

?>